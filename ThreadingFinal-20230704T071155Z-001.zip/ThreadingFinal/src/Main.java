import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Fibonacci fibonacci = new Fibonacci(1001);
        Square square = new Square(1002);
        Sortnumbers sortNumbers = new Sortnumbers(1003);
        try {
            fibonacci.start();
            fibonacci.join();
            square.start();
            square.join();
            sortNumbers.start();
            sortNumbers.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("All processes complete.");
    }
}

class Fibonacci extends Thread {
    private int num;
    private int pid;

    public Fibonacci(int pid) {
        Random rand = new Random();
        this.num = rand.nextInt(20);
        this.pid = rand.nextInt(1000);
    }

    public void run() {
        System.out.println("------------------------------------------------------------");
        System.out.println("Fibonacci Number Series (Process ID: " + pid + "):");
        int firstnum = 0;
        int secondnum = 1;
        System.out.print(firstnum + ", ");
        System.out.print(secondnum + ", ");
        for (int i = 2; i < num; i++){
            int next = firstnum + secondnum;
            System.out.print(next + ", ");
            firstnum = secondnum;
            secondnum = next;
        }
        System.out.println("\n------------------------------------------------------------");
    }
}

class Square extends Thread {
    private int n;
    private int pid;

    public Square(int pid) {
        Random rand = new Random();
        this.n = rand.nextInt(25);
        this.pid = rand.nextInt(1000);
    }

    public void run() {
        System.out.println("Square of Numbers (Process ID: " + pid + "):");
        int num = n;
        int square = n * n;
        System.out.print(n + " x "+ n + " = "+ square + " ");
        System.out.println("\n-----------------------------------------");
    }
}

class Sortnumbers extends Thread {
    private int[] num;
    private int n;
    private int pid;

    public Sortnumbers(int pid) {
        Random rand = new Random();
        n = 10;
        num = new int[n];
        for (int i = 0; i < num.length; i++) {
            num[i] = rand.nextInt(100);
        }
        this.pid = rand.nextInt(1000);
    }

    public void run() {
        System.out.println("Sorted Numbers (Process ID: " + pid + "):");
        for (int i = 0; i < num.length; i++) {
            for (int j = i + 1; j < num.length; j++) {
                if (num[j] < num[i]) {
                    int temp = num[j];
                    num[j] = num[i];
                    num[i] = temp;
                }
            }
        }
        for (int number : num) {
            System.out.print(number + ", ");
        }
        System.out.println("\n-----------------------------------------");
    }
}